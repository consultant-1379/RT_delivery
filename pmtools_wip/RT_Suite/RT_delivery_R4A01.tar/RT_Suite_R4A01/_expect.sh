#!/usr/local/bin/expect

set command [lindex $argv 0];

set timeout 600

eval spawn su -

expect "Password:"

send "shroot\r"

expect "*{root}*"

send "su - hyperic -c '$command'\r"

expect "*{root}*"

send "exit\r"

