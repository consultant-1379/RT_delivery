#!/usr/bin/perl
use warnings;
use strict;

#
#-- get current directory
use Cwd;

if ( $< != 0 ) {
	print "\n\tThis script must be executed as root user\n\n";
        exit (0);
}

if (@ARGV < 2) {
	print STDERR "\n\tUsage: perl $0 <epfg_package.zip> <RT_inputFile>\n\n";
	exit 1;
}

my $epfgPkg = $ARGV[0];
my $RT_inputFile = $ARGV[1];

chdir("/eniq/home/dcuser") or die "cannot change: $!\n";
print(cwd);
print "\n\n";

system("/usr/bin/rm -rf CPAN_Modules");
sleep(2);

system("/usr/bin/unzip CPAN_Modules.zip");
sleep(3);

system("perl cpanInstallerScript.pl");
sleep(15);

system("perl executeRT.pl $epfgPkg $RT_inputFile");
